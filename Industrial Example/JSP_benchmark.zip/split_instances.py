"""
将 OR-Library 的 jobshop1.txt 拆分成独立的实例文件。
OR-Library 共 82 个 JSP 实例：abz5-9, ft06/ft10/ft20, la01-40, orb01-10, swv01-20, yn1-4
"""
import re
import os

BASE = r"D:\OneDrive\文档\Trae-CN\temp_20261028_01\jsp_benchmark"
SRC = os.path.join(BASE, "jobshop1.txt")
OUT = os.path.join(BASE, "instances")

os.makedirs(OUT, exist_ok=True)

with open(SRC, "r", encoding="utf-8", errors="ignore") as f:
    content = f.read()

# 按 "instance <name>" 拆分
pattern = re.compile(r"instance\s+(\S+)\s*\n\s*\n\s*\+{5,}\s*\n\s*(.+?)\s*\n\s*(\d+)\s+(\d+)\s*\n", re.DOTALL)

instances = pattern.findall(content)
print(f"共找到 {len(instances)} 个实例")

manifest = []
for name, desc, njobs, nmachines in instances:
    # 找到该实例开始位置，读取后续 njobs 行 + 最优值注释
    idx = content.find(f"instance {name}")
    # 定位到 "njobs nmachines" 行之后
    header_pattern = re.compile(rf"instance\s+{re.escape(name)}\s*\n\s*\n\s*\+{{5,}}\s*\n\s*.+?\s*\n\s*\d+\s+\d+\s*\n", re.DOTALL)
    m = header_pattern.search(content, idx)
    if not m:
        print(f"  [SKIP] {name}: header not found")
        continue
    data_start = m.end()
    # 找到下一个 "++++++++++++" 分隔符
    next_sep = content.find("+++++", data_start)
    if next_sep == -1:
        next_sep = len(content)
    block = content[data_start:next_sep].strip()
    # 只保留 njobs 行（每行偶数个数字）
    lines = [ln for ln in block.split("\n") if ln.strip() and not ln.strip().startswith("++")]
    lines = lines[:int(njobs)]

    out_path = os.path.join(OUT, f"{name}.txt")
    with open(out_path, "w", encoding="utf-8") as wf:
        wf.write(f"{njobs} {nmachines}\n")
        for ln in lines:
            wf.write(ln.strip() + "\n")

    manifest.append((name, njobs, nmachines, desc.strip()[:60]))
    print(f"  [OK]  {name}: {njobs}x{nmachines}")

# 写清单
with open(os.path.join(BASE, "instances_manifest.csv"), "w", encoding="utf-8") as wf:
    wf.write("name,jobs,machines,description\n")
    for row in manifest:
        wf.write(f"{row[0]},{row[1]},{row[2]},{row[3]}\n")

print(f"\n拆分完成！共 {len(manifest)} 个实例保存在 {OUT}")
